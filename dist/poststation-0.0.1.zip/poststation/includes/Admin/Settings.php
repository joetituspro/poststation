<?php

namespace PostStation\Admin;

class Settings
{
	private const OPTION_KEY = 'poststation_api_key';
	private const MENU_SLUG = 'poststation';

	public function __construct()
	{
		add_action('admin_init', [$this, 'register_settings']);
	}

	public function register_settings(): void
	{
		register_setting(self::MENU_SLUG . '_settings', self::OPTION_KEY);
	}

	public function render_settings_page(): void
	{
		$api_key = get_option(self::OPTION_KEY, '');
		?>
		<div class="wrap">
			<h1><?php echo esc_html(get_admin_page_title()); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields(self::MENU_SLUG . '_settings'); ?>
				<table class="form-table">
					<tr>
						<th scope="row"><?php _e('API Key', 'poststation'); ?></th>
						<td>
							<input type="text" id="<?php echo esc_attr(self::OPTION_KEY); ?>"
								name="<?php echo esc_attr(self::OPTION_KEY); ?>" value="<?php echo esc_attr($api_key); ?>"
								class="regular-text" readonly>
							<p class="description">
								<?php _e('Use this API key in your requests with the X-API-Key header.', 'poststation'); ?>
							</p>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<hr>

			<div class="poststation-api-docs">
				<h2><?php _e('API Documentation', 'poststation'); ?></h2>
				<p><?php _e('You can use the following endpoints to create posts programmatically.', 'poststation'); ?></p>

				<table class="widefat striped" style="margin-top: 20px;">
					<thead>
						<tr>
							<th><?php _e('Method', 'poststation'); ?></th>
							<th><?php _e('Endpoint', 'poststation'); ?></th>
							<th><?php _e('Description', 'poststation'); ?></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><code>POST</code></td>
							<td><code><?php echo esc_url(rest_url('poststation/v1/create')); ?></code></td>
							<td><?php _e('WordPress REST API endpoint', 'poststation'); ?></td>
						</tr>
						<tr>
							<td><code>POST</code></td>
							<td><code><?php echo esc_url(site_url('ps-api/create')); ?></code></td>
							<td><?php _e('Custom API endpoint', 'poststation'); ?></td>
						</tr>
					</tbody>
				</table>

				<h3><?php _e('Authentication', 'poststation'); ?></h3>
				<p><?php _e('All requests must include the following HTTP header:', 'poststation'); ?></p>
				<code>X-API-Key: <?php echo esc_html($api_key); ?></code>

				<h3><?php _e('Request Body (JSON)', 'poststation'); ?></h3>
				<p><?php _e('Send a JSON object with the following fields:', 'poststation'); ?></p>
				<div style="background: #f6f7f7; padding: 15px; border-left: 4px solid #72aee6; overflow-x: auto;">
					<pre style="margin: 0;">{
  "title": "Post Title",
  "content": "Post content with &lt;h2&gt;headers&lt;/h2&gt; and other HTML tags.",
  "slug": "custom-post-slug",
  "thumbnail_url": "https://example.com/image.jpg",
  "taxonomies": {
    "category": ["News", "Updates"],
    "post_tag": ["WordPress", "API"]
  },
  "custom_fields": {
    "your_meta_key": "your_meta_value"
  },
  "block_id": 123
}</pre>
				</div>

				<p style="margin-top: 15px;">
					<strong><?php _e('Field Descriptions:', 'poststation'); ?></strong>
				</p>
				<ul class="ul-disc">
					<li><strong>title</strong> (<?php _e('string', 'poststation'); ?>): <?php _e('The title of the post.', 'poststation'); ?></li>
					<li><strong>content</strong> (<?php _e('string', 'poststation'); ?>): <?php _e('The content of the post. HTML is supported.', 'poststation'); ?></li>
					<li><strong>slug</strong> (<?php _e('string, optional', 'poststation'); ?>): <?php _e('The URL slug for the post.', 'poststation'); ?></li>
					<li><strong>thumbnail_url</strong> (<?php _e('string, optional', 'poststation'); ?>): <?php _e('URL of an image to be used as the featured image.', 'poststation'); ?></li>
					<li><strong>taxonomies</strong> (<?php _e('object, optional', 'poststation'); ?>): <?php _e('An object where keys are taxonomy names and values are arrays of term names.', 'poststation'); ?></li>
					<li><strong>custom_fields</strong> (<?php _e('object, optional', 'poststation'); ?>): <?php _e('An object of meta keys and values to be stored with the post.', 'poststation'); ?></li>
					<li><strong>block_id</strong> (<?php _e('integer, optional', 'poststation'); ?>): <?php _e('The ID of a PostBlock. If provided, the block status will be updated to "completed" upon success.', 'poststation'); ?></li>
				</ul>
			</div>
		</div>
		<style>
			.poststation-api-docs {
				margin-top: 30px;
				padding: 20px;
				background: #fff;
				border: 1px solid #ccd0d4;
				box-shadow: 0 1px 1px rgba(0,0,0,.04);
			}
			.poststation-api-docs h2 { margin-top: 0; }
			.poststation-api-docs code {
				background: #f0f0f1;
				padding: 3px 5px;
				border-radius: 3px;
			}
			.poststation-api-docs pre {
				font-family: monospace;
				font-size: 13px;
				line-height: 1.5;
			}
		</style>
		<?php
	}

	public static function get_menu_slug(): string
	{
		return self::MENU_SLUG;
	}
}